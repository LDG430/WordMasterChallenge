import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tile } from "./tile";

interface HowToPlayProps {
  open: boolean;
  onClose: () => void;
}

export function HowToPlay({ open, onClose }: HowToPlayProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>How to Play</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p>
            Guess the word in 6 tries. After each guess, the color of the tiles will
            change to show how close your guess was to the word.
          </p>
          <div className="space-y-2">
            <div className="flex gap-2">
              <Tile letter="W" state="correct" revealed={true} />
              <Tile letter="O" state="absent" revealed={true} />
              <Tile letter="R" state="present" revealed={true} />
              <Tile letter="D" state="absent" revealed={true} />
              <Tile letter="S" state="absent" revealed={true} />
            </div>
            <p className="text-sm">
              <span className="font-bold">W</span> is in the word and in the correct spot.
            </p>
            <p className="text-sm">
              <span className="font-bold">R</span> is in the word but in the wrong spot.
            </p>
            <p className="text-sm">
              <span className="font-bold">O, D, S</span> are not in the word.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
