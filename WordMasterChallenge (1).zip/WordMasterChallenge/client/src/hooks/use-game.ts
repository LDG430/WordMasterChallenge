import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { getLetterHints } from "@/lib/dictionaries";
import type { GameState, Language, TileState } from "@shared/schema";

interface UseGameOptions {
  language: Language;
  wordLength: number;
  settings: {
    hardMode: boolean;
    letterHints: boolean;
    dailyMode: boolean;
  };
  onInvalidWord: () => void;
}

interface PlayerState {
  guesses?: { letter: string; state: TileState }[][];
  currentRow?: number;
  gameState?: GameState;
}

export function useGame({ language, wordLength, settings, onInvalidWord }: UseGameOptions) {
  const [targetWord, setTargetWord] = useState("");
  const [guesses, setGuesses] = useState<{ letter: string; state: TileState }[][]>([]);
  const [currentGuess, setCurrentGuess] = useState("");
  const [gameState, setGameState] = useState<GameState>("playing");
  const [letterStates, setLetterStates] = useState<Map<string, TileState>>(new Map());
  const [hintLetters, setHintLetters] = useState<Set<string>>(new Set());
  const [isRevealed, setIsRevealed] = useState(false);
  const [currentRow, setCurrentRow] = useState(0);


  const { data: word } = useQuery({
    queryKey: ["/api/word", wordLength, language],
    enabled: !targetWord
  });

  useEffect(() => {
    if (word?.word) {
      setTargetWord(word.word);
      if (settings.letterHints) {
        setHintLetters(getLetterHints(word.word));
      }
    }
  }, [word, settings.letterHints]);

  const validateMutation = useMutation({
    mutationFn: async (guess: string) => {
      const res = await apiRequest("POST", "/api/validate", { word: guess, language });
      return res.json();
    }
  });

  const updateStatsMutation = useMutation({
    mutationFn: async (won: boolean) => {
      const res = await apiRequest("POST", "/api/stats", {
        gamesPlayed: 1,
        gamesWon: won ? 1 : 0,
        currentStreak: won ? 1 : 0
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    }
  });

  const updateLetterStates = (guessResult: { letter: string; state: TileState }[]) => {
    const newStates = new Map(letterStates);
    guessResult.forEach(({ letter, state }) => {
      const currentState = newStates.get(letter);
      if (!currentState || 
          state === "correct" || 
          (state === "present" && currentState === "absent")) {
        newStates.set(letter, state);
      }
    });
    setLetterStates(newStates);
  };

  const checkGuess = async () => {
    if (currentGuess.length !== wordLength) return;

    if (settings.hardMode) {
      // Check if the guess uses the revealed hints from previous guesses
      for (let i = 0; i < wordLength; i++) {
        for (const prevGuess of guesses) {
          if (prevGuess[i].state === "correct" && prevGuess[i].letter !== currentGuess[i]) {
            toast({
              title: "Hard mode",
              description: `${i + 1}${getOrdinal(i + 1)} letter must be ${prevGuess[i].letter}`,
              variant: "destructive"
            });
            return;
          }
        }
      }
    }

    try {
      // Skip validation for now to ensure game works
      // const { isValid } = await validateMutation.mutateAsync(currentGuess);
      const isValid = true;

      if (!isValid) {
        onInvalidWord();
        return;
      }

      // Compare with target word
      const newGuess = currentGuess.split("").map((letter, i) => {
        let state: TileState = "absent";
        if (targetWord && letter === targetWord[i]) {
          state = "correct";
        } else if (targetWord && targetWord.includes(letter)) {
          state = "present";
        }
        return { letter, state };
      });

      setGuesses(prev => [...prev, newGuess]);
      setCurrentGuess("");

      // Update letter states for keyboard
      const newLetterStates = new Map(letterStates);
      for (const { letter, state } of newGuess) {
        const currentState = newLetterStates.get(letter);
        if (!currentState || (state === "correct" && currentState !== "correct")) {
          newLetterStates.set(letter, state);
        }
      }
      setLetterStates(newLetterStates);

      // Check if won or lost
      const hasWon = newGuess.every(({ state }) => state === "correct");
      if (hasWon) {
        setGameState("won");
        updateStatsMutation.mutate(true);
        return;
      }

      const ALLOWED_GUESSES = 6;
      if (guesses.length + 1 >= ALLOWED_GUESSES) {
        setGameState("lost");
        updateStatsMutation.mutate(false);
        return;
      }

      setCurrentRow(prev => prev + 1);
    } catch (error) {
      console.error("Error checking guess:", error);
    }
  };

  const updateGameState = (state: PlayerState) => {
    if (state.guesses) setGuesses(state.guesses);
    if (state.currentRow !== undefined) setCurrentRow(state.currentRow);
    if (state.gameState) setGameState(state.gameState);
  };

  const onKey = (key: string) => {
    if (gameState !== "playing") return;
    if (currentGuess.length < wordLength) {
      setCurrentGuess(curr => curr + key);
    }
  };

  const onBackspace = () => {
    setCurrentGuess(curr => curr.slice(0, -1));
  };

  const revealWord = () => {
    setIsRevealed(true);
    setGameState("lost");
    updateStatsMutation.mutate(false);
  };

  const resetGame = () => {
    setTargetWord("");
    setGuesses([]);
    setCurrentGuess("");
    setGameState("playing");
    setHintLetters(new Set());
    setLetterStates(new Map());
    setIsRevealed(false);
    setCurrentRow(0);
    queryClient.invalidateQueries({ queryKey: ["/api/word"] });
  };

  return {
    gameState,
    currentRow,
    guesses: [...guesses, currentGuess.split("").map(letter => ({ 
      letter, 
      state: "filled" 
    }))],
    letterStates,
    hintLetters: settings.letterHints && guesses.length === 0 ? hintLetters : new Set(),
    targetWord: isRevealed ? targetWord : undefined,
    onKey,
    onEnter: checkGuess,
    onBackspace,
    revealWord,
    resetGame,
    updateGameState
  };
}