
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { GameStats } from "@shared/schema";

interface StatsProps {
  open: boolean;
  onClose: () => void;
  stats?: GameStats;
}

export function Stats({ open, onClose, stats }: StatsProps) {
  if (!stats) return null;

  const winPercentage = stats.gamesPlayed > 0 
    ? Math.round((stats.gamesWon / stats.gamesPlayed) * 100) 
    : 0;

  const maxDistribution = Math.max(...stats.distribution);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Statistics</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-4 gap-4 text-center mb-6">
          <div>
            <div className="text-2xl font-bold">{stats.gamesPlayed}</div>
            <div className="text-xs">Played</div>
          </div>
          <div>
            <div className="text-2xl font-bold">{winPercentage}</div>
            <div className="text-xs">Win %</div>
          </div>
          <div>
            <div className="text-2xl font-bold">{stats.currentStreak}</div>
            <div className="text-xs">Current Streak</div>
          </div>
          <div>
            <div className="text-2xl font-bold">{stats.maxStreak}</div>
            <div className="text-xs">Max Streak</div>
          </div>
        </div>
        <div className="space-y-2">
          <h3 className="font-bold mb-3">Guess Distribution</h3>
          {stats.distribution.map((count, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="w-4">{index + 1}</div>
              <div 
                className="bg-green-600 h-5 rounded"
                style={{ 
                  width: `${maxDistribution > 0 ? (count / maxDistribution) * 100 : 0}%`,
                  minWidth: count > 0 ? '20px' : '0'
                }}
              >
                <span className="px-2 text-white">{count}</span>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
