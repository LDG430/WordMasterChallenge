import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { GameBoard } from "./board";
import type { PlayerState } from "@shared/schema";

interface MultiplayerStatusProps {
  roomId: string | null;
  playerId: string;
  playerName: string;
  players: Record<string, PlayerState>;
  onSetPlayerName: (name: string) => void;
  onCreateRoom: () => Promise<void>;
  onJoinRoom: (roomId: string) => void;
  wordLength: number;
  colorBlindMode?: boolean;
}

export function MultiplayerStatus({
  roomId,
  playerId,
  playerName,
  players,
  onSetPlayerName,
  onCreateRoom,
  onJoinRoom,
  wordLength,
  colorBlindMode
}: MultiplayerStatusProps) {
  const [showJoinDialog, setShowJoinDialog] = useState(false);
  const [joinRoomId, setJoinRoomId] = useState("");

  if (!roomId) {
    return (
      <div className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => onSetPlayerName(e.target.value)}
          />
        </div>
        <div className="flex gap-2 justify-center">
          <Button
            onClick={() => onCreateRoom()}
            disabled={!playerName}
          >
            Create Multiplayer Room
          </Button>
          <Button
            onClick={() => setShowJoinDialog(true)}
            disabled={!playerName}
          >
            Join Room
          </Button>
        </div>

        <Dialog open={showJoinDialog} onOpenChange={setShowJoinDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Join Room</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Enter room code"
                value={joinRoomId}
                onChange={(e) => setJoinRoomId(e.target.value.toUpperCase())}
              />
              <Button
                onClick={() => {
                  onJoinRoom(joinRoomId);
                  setShowJoinDialog(false);
                }}
                disabled={!joinRoomId}
              >
                Join
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="text-center">
        <p className="text-sm text-muted-foreground">Room Code: {roomId}</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {Object.entries(players)
          .filter(([pid]) => pid !== playerId)
          .map(([pid, player]) => (
            <div key={pid} className="space-y-2">
              <h3 className="font-bold">{player.name}</h3>
              <div className="scale-75 origin-top">
                <GameBoard
                  wordLength={wordLength}
                  currentRow={player.currentRow}
                  guesses={player.guesses}
                  colorBlindMode={colorBlindMode}
                />
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}