import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { GameBoard } from "@/components/game/board";
import { Keyboard } from "@/components/game/keyboard";
import { Stats } from "@/components/game/stats";
import { HowToPlay } from "@/components/game/how-to-play";
import { SettingsPanel, SettingsButton } from "@/components/game/settings";
import { MultiplayerStatus } from "@/components/game/multiplayer-status";
import { MultiplayerDialog } from "@/components/game/multiplayer-dialog";
import { useGame } from "@/hooks/use-game";
import { useMultiplayer } from "@/hooks/use-multiplayer";
import type { Language, PlayerState } from "@shared/schema";

export default function Home() {
  const [language, setLanguage] = useState<Language>("en");
  const [wordLength, setWordLength] = useState(5);
  const [showStats, setShowStats] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showMultiplayer, setShowMultiplayer] = useState(false);
  const [settings, setSettings] = useState({
    hardMode: false,
    dailyMode: false,
    colorBlindMode: false,
    letterHints: false,
    confettiAnimation: true,
    swapButtons: false,
  });

  const { toast } = useToast();
  const { 
    gameState, 
    currentRow, 
    guesses, 
    letterStates,
    targetWord,
    onKey, 
    onEnter, 
    onBackspace,
    revealWord,
    resetGame,
    updateGameState 
  } = useGame({
    language,
    wordLength,
    settings,
    onInvalidWord: () => {
      toast({
        title: "Invalid word",
        description: "Please enter a valid word",
        variant: "destructive"
      });
    }
  });

  const {
    roomId,
    playerId,
    playerName,
    players,
    setPlayerName,
    createRoom,
    joinRoom,
    updateGameState: updateMultiplayerState
  } = useMultiplayer({
    language,
    wordLength,
    onGameStateUpdate: (state: PlayerState) => {
      updateGameState(state);
    }
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"]
  });

  const handleSettingChange = (setting: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [setting]: !prev[setting] }));
  };

  useEffect(() => {
    if (roomId) {
      updateMultiplayerState({
        guesses,
        currentRow,
        gameState
      });
    }
  }, [roomId, guesses, currentRow, gameState, updateMultiplayerState]);

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-lg mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Word Puzzle</h1>
          <div className="flex items-center gap-2">
            <Select value={language} onValueChange={(v) => setLanguage(v as Language)}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Spanish</SelectItem>
                <SelectItem value="fr">French</SelectItem>
                <SelectItem value="de">German</SelectItem>
              </SelectContent>
            </Select>
            <Select value={wordLength.toString()} onValueChange={(v) => setWordLength(Number(v))}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[4, 5, 6, 7].map(n => (
                  <SelectItem key={n} value={n.toString()}>{n} letters</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <SettingsButton onClick={() => setShowSettings(true)} />
          </div>
        </div>

        <div className="flex justify-center mb-4">
          <Button 
            variant="outline" 
            onClick={() => setShowMultiplayer(true)}
          >
            Multiplayer
          </Button>
        </div>

        {targetWord && (
          <div className="text-center text-lg font-bold">
            The word was: {targetWord}
          </div>
        )}

        <MultiplayerStatus
          roomId={roomId}
          playerId={playerId}
          playerName={playerName}
          players={players}
          onSetPlayerName={setPlayerName}
          onCreateRoom={createRoom}
          onJoinRoom={joinRoom}
          wordLength={wordLength}
          colorBlindMode={settings.colorBlindMode}
        />

        <GameBoard
          wordLength={wordLength}
          currentRow={currentRow}
          guesses={guesses}
          colorBlindMode={settings.colorBlindMode}
        />

        <Keyboard
          language={language}
          onKey={onKey}
          onEnter={onEnter}
          onBackspace={onBackspace}
          swapButtons={settings.swapButtons}
          hintLetters={settings.letterHints ? hintLetters : new Set()}
          letterStates={letterStates}
        />

        <div className="flex justify-center gap-2 flex-wrap">
          <Button onClick={() => setShowHelp(true)}>How to Play</Button>
          <Button onClick={() => setShowStats(true)}>Statistics</Button>
          <Button onClick={resetGame}>New Game</Button>
          {gameState === "playing" && (
            <Button variant="destructive" onClick={revealWord}>Give Up</Button>
          )}
        </div>

        <Stats
          open={showStats}
          onClose={() => setShowStats(false)}
          stats={stats}
        />

        <HowToPlay
          open={showHelp}
          onClose={() => setShowHelp(false)}
        />

        {/* Only render dialog when showMultiplayer is true */}
        {showMultiplayer && (
          <MultiplayerDialog
            open={showMultiplayer}
            onClose={() => setShowMultiplayer(false)}
            playerName={playerName}
            onSetPlayerName={setPlayerName}
            onCreateRoom={createRoom}
            onJoinRoom={joinRoom}
          />
        )}

        <SettingsPanel
          open={showSettings}
          onClose={() => setShowSettings(false)}
          settings={settings}
          onSettingChange={handleSettingChange}
        />
      </div>
    </div>
  );
}