import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const gameStats = pgTable("game_stats", {
  id: serial("id").primaryKey(),
  gamesPlayed: integer("games_played").default(0),
  gamesWon: integer("games_won").default(0),
  currentStreak: integer("current_streak").default(0),
  maxStreak: integer("max_streak").default(0),
  distribution: integer("distribution").array().default([0,0,0,0,0,0]),
});

export const insertGameStatsSchema = createInsertSchema(gameStats).omit({ 
  id: true 
});

export type GameStats = typeof gameStats.$inferSelect;
export type InsertGameStats = z.infer<typeof insertGameStatsSchema>;

export type Language = 'en' | 'es' | 'fr' | 'de';
export type GameState = 'playing' | 'won' | 'lost';
export type TileState = 'empty' | 'filled' | 'correct' | 'present' | 'absent';

// Multiplayer types
export type PlayerState = {
  id: string;
  name: string;
  guesses: { letter: string; state: TileState }[][];
  currentRow: number;
  gameState: GameState;
};

export type MultiplayerGameState = {
  roomId: string;
  word: string;
  language: Language;
  wordLength: number;
  players: Record<string, PlayerState>;
};

// WebSocket message types
export type WSMessage = {
  type: 'join' | 'leave' | 'update' | 'sync';
  roomId: string;
  playerId: string;
  playerName?: string;
  gameState?: Partial<PlayerState>;
};