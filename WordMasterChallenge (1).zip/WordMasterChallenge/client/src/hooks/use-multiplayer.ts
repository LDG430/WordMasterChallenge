import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { MultiplayerGameState, PlayerState, WSMessage } from "@shared/schema";

interface UseMultiplayerOptions {
  language: string;
  wordLength: number;
  onGameStateUpdate: (state: PlayerState) => void;
}

export function useMultiplayer({ language, wordLength, onGameStateUpdate }: UseMultiplayerOptions) {
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [playerId] = useState(() => Math.random().toString(36).substring(2, 8));
  const [playerName, setPlayerName] = useState("");
  const [players, setPlayers] = useState<Record<string, PlayerState>>({});

  const createRoomMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/rooms", { language, wordLength });
      return res.json();
    }
  });

  const { data: roomData } = useQuery({
    queryKey: ["/api/rooms", roomId],
    enabled: !!roomId
  });

  const connectToRoom = useCallback((rid: string) => {
    if (!playerName) return;

    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${wsProtocol}//${window.location.host}/ws`); // Updated WebSocket path

    ws.onopen = () => {
      console.log('WebSocket connection established');
      ws.send(JSON.stringify({
        type: 'join',
        roomId: rid,
        playerId,
        playerName
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message: WSMessage = JSON.parse(event.data);
        console.log('Received message:', message.type);

        if (message.type === 'sync' && message.gameState) {
          if (message.playerId === playerId) {
            onGameStateUpdate(message.gameState as PlayerState);
          }
          setPlayers(prev => ({
            ...prev,
            [message.playerId]: message.gameState as PlayerState
          }));
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    ws.onclose = () => {
      console.log('WebSocket connection closed');
    };

    setWs(ws);
    setRoomId(rid);

    return () => {
      ws.close();
    };
  }, [playerId, playerName, onGameStateUpdate]);

  const createRoom = async () => {
    const { roomId } = await createRoomMutation.mutateAsync();
    connectToRoom(roomId);
    return roomId;
  };

  const joinRoom = (rid: string) => {
    connectToRoom(rid);
  };

  const updateGameState = useCallback((state: Partial<PlayerState>) => {
    if (ws && ws.readyState === WebSocket.OPEN && roomId) {
      ws.send(JSON.stringify({
        type: 'update',
        roomId,
        playerId,
        gameState: state
      }));
    }
  }, [ws, roomId, playerId]);

  useEffect(() => {
    if (roomData) {
      setPlayers(roomData.players || {});
    }
  }, [roomData]);

  useEffect(() => {
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, [ws]);

  return {
    roomId,
    playerId,
    playerName,
    players,
    setPlayerName,
    createRoom,
    joinRoom,
    updateGameState,
    isLoading: createRoomMutation.isPending
  };
}