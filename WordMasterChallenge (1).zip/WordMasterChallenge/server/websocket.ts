import { WebSocket, WebSocketServer } from 'ws';
import { Server } from 'http';
import { storage } from './storage';
import type { WSMessage } from '@shared/schema';

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ 
    server,
    path: '/ws' // Add dedicated path
  });

  console.log('WebSocket server initialized');

  const rooms = new Map<string, Set<WebSocket>>();

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');

    let currentRoom: string | null = null;
    let playerId: string | null = null;

    ws.on('message', async (data) => {
      try {
        const message: WSMessage = JSON.parse(data.toString());
        console.log('Received message:', message.type, 'from player:', message.playerId);

        switch (message.type) {
          case 'join': {
            if (currentRoom) {
              const roomClients = rooms.get(currentRoom);
              if (roomClients) {
                roomClients.delete(ws);
                if (roomClients.size === 0) {
                  rooms.delete(currentRoom);
                }
              }
            }

            currentRoom = message.roomId;
            playerId = message.playerId;

            if (!rooms.has(currentRoom)) {
              rooms.set(currentRoom, new Set());
            }
            rooms.get(currentRoom)!.add(ws);

            const gameState = await storage.joinRoom(currentRoom, playerId, message.playerName || 'Anonymous');
            if (gameState) {
              const response: WSMessage = {
                type: 'sync',
                roomId: currentRoom,
                playerId,
                gameState: gameState.players[playerId]
              };

              // Broadcast to all clients in the room
              rooms.get(currentRoom)!.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                  client.send(JSON.stringify(response));
                }
              });

              console.log('Player', playerId, 'joined room:', currentRoom);
            }
            break;
          }

          case 'update': {
            if (!currentRoom || !playerId) break;

            const gameState = await storage.updatePlayerState(
              currentRoom,
              playerId,
              message.gameState || {}
            );

            if (gameState) {
              const response: WSMessage = {
                type: 'sync',
                roomId: currentRoom,
                playerId,
                gameState: gameState.players[playerId]
              };

              rooms.get(currentRoom)!.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                  client.send(JSON.stringify(response));
                }
              });

              console.log('Updated state for player', playerId, 'in room:', currentRoom);
            }
            break;
          }
        }
      } catch (error) {
        console.error('WebSocket error:', error);
      }
    });

    ws.on('close', async () => {
      if (currentRoom && playerId) {
        await storage.leaveRoom(currentRoom, playerId);
        const roomClients = rooms.get(currentRoom);
        if (roomClients) {
          roomClients.delete(ws);
          if (roomClients.size === 0) {
            rooms.delete(currentRoom);
          }
        }
        console.log('Player', playerId, 'left room:', currentRoom);
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket connection error:', error);
    });
  });

  return wss;
}