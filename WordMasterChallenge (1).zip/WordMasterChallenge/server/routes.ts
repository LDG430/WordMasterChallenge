import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupWebSocket } from "./websocket";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/stats", async (_req, res) => {
    const stats = await storage.getGameStats();
    res.json(stats);
  });

  app.post("/api/stats", async (req, res) => {
    const stats = await storage.updateGameStats(req.body);
    res.json(stats);
  });

  app.get("/api/word", async (req, res) => {
    const { length = 5, language = 'en' } = req.query;
    const word = await storage.getRandomWord(Number(length), String(language));
    res.json({ word });
  });

  app.post("/api/validate", async (req, res) => {
    const { word, language = 'en' } = req.body;
    const isValid = await storage.validateWord(word, language);
    res.json({ isValid });
  });

  // Multiplayer endpoints
  app.post("/api/rooms", async (req, res) => {
    const { language = 'en', wordLength = 5 } = req.body;
    const roomId = await storage.createRoom(language, wordLength);
    res.json({ roomId });
  });

  app.get("/api/rooms/:roomId", async (req, res) => {
    const { roomId } = req.params;
    const room = await storage.getRoomState(roomId);
    if (!room) {
      res.status(404).json({ message: "Room not found" });
      return;
    }
    res.json(room);
  });

  const httpServer = createServer(app);
  setupWebSocket(httpServer);
  return httpServer;
}