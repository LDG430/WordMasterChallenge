import { Tile } from "./tile";
import type { TileState } from "@shared/schema";

interface GameBoardProps {
  wordLength: number;
  currentRow: number;
  guesses: { letter: string; state: TileState }[][];
  colorBlindMode?: boolean;
}

export function GameBoard({ wordLength, currentRow, guesses, colorBlindMode }: GameBoardProps) {
  return (
    <div className="grid gap-2">
      {Array.from({ length: 6 }).map((_, row) => (
        <div key={row} className="flex justify-center gap-2">
          {Array.from({ length: wordLength }).map((_, col) => {
            const guess = guesses[row]?.[col];
            return (
              <Tile
                key={col}
                letter={guess?.letter || ""}
                state={guess?.state || "empty"}
                revealed={row < currentRow}
                colorBlindMode={colorBlindMode}
              />
            );
          })}
        </div>
      ))}
    </div>
  );
}