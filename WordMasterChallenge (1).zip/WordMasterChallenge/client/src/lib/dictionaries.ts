// Word lists for different languages
// Each language contains arrays of words grouped by length (4-7 letters)
// All words are in uppercase for consistency

export const dictionaries = {
  en: {
    4: [
      "ABLE", "ACID", "AGED", "ALSO", "AREA", "ARMY", "AWAY", "BABY", "BACK", "BALL",
      "BAND", "BANK", "BASE", "BATH", "BEAR", "BEAT", "BEEN", "BEER", "BELL", "BELT",
      "BEST", "BIKE", "BIRD", "BLUE", "BOAT", "BODY", "BOMB", "BOND", "BONE", "BOOK",
      "BORN", "BOTH", "BOWL", "BULK", "BURN", "BUSH", "BUSY", "CALM", "CAME", "CAMP",
      "CARD", "CARE", "CASE", "CASH", "CAST", "CHAT", "CHIP", "CITY", "CLUB", "COAL"
    ],
    5: [
      "ABOUT", "ABOVE", "ABUSE", "ACTOR", "ACUTE", "ADMIT", "ADOPT", "ADULT", "AFTER", "AGAIN",
      "AGENT", "AGREE", "AHEAD", "ALARM", "ALBUM", "ALERT", "ALIKE", "ALIVE", "ALLOW", "ALONE",
      "ALONG", "ALTER", "AMONG", "ANGER", "ANGLE", "ANGRY", "APART", "APPLE", "APPLY", "ARENA",
      "ARGUE", "ARISE", "ARRAY", "ASIDE", "ASSET", "AUDIO", "AUDIT", "AVOID", "AWARD", "AWARE",
      "BADLY", "BAKER", "BASES", "BASIC", "BASIS", "BEACH", "BEGAN", "BEGIN", "BLACK", "BLAME"
    ],
    6: [
      "ABROAD", "ACCEPT", "ACCESS", "ACROSS", "ACTING", "ACTION", "ACTIVE", "ACTUAL", "ADVICE", "ADVISE",
      "AFFECT", "AFFORD", "AFRAID", "AGENCY", "AGENDA", "AGENTS", "AGREED", "AHEAD", "ALCOHOL", "ALIENS",
      "ALIVE", "ALLIED", "ALLOWS", "ALMOST", "ALONE", "ALONG", "ALWAYS", "AMOUNT", "ANIMAL", "ANNUAL",
      "ANSWER", "ANYONE", "ANYWAY", "APPEAL", "APPEAR", "APPLE", "APPLY", "ARGUE", "ARISE", "AROUND",
      "ARRIVE", "ARTIST", "ASKING", "ASPECT", "ASSIGN", "ASSIST", "ASSUME", "ATTACK", "ATTEND", "AUGUST"
    ],
    7: [
      "ABANDON", "ABILITY", "ABOLISH", "ABSENCE", "ABSOLUTE", "ABSORB", "ABSTRACT", "ABSURD", "ABUSE", "ACADEMY",
      "ACCEPT", "ACCESS", "ACCOUNT", "ACCUSE", "ACHIEVE", "ACQUIRE", "ACROSS", "ACTING", "ACTION", "ACTIVE",
      "ACTUAL", "ADAPT", "ADDICTION", "ADDRESS", "ADJUST", "ADMIRE", "ADMIT", "ADOPT", "ADVANCE", "ADVICE",
      "ADVISE", "AFFAIR", "AFFECT", "AFFORD", "AFRAID", "AGENCY", "AGENDA", "AGENT", "AGREE", "AHEAD",
      "ALCOHOL", "ALERT", "ALIEN", "ALIKE", "ALIVE", "ALLIANCE", "ALLOW", "ALMOST", "ALONE", "ALONG"
    ]
  },
  es: {
    4: [
      "AGUA", "AIRE", "ALTO", "AMOR", "ARTE", "AZUL", "BAJA", "BAJO", "BEBE", "BIEN",
      "BOCA", "BODA", "BRAZO", "CAFE", "CAJA", "CAMA", "CARA", "CASA", "CENA", "CINE",
      "CITA", "CLUB", "COLA", "COMO", "COSA", "CRUZ", "CUBO", "DATO", "DEDO", "DIAS",
      "DICE", "DIOS", "DISCO", "DUDA", "EDAD", "ELLA", "EURO", "FAMA", "FASE", "FIEL",
      "FILA", "FILM", "FINAL", "FLOR", "FOCO", "FOTO", "FRIO", "GATO", "GRIS", "GUIA"
    ],
    5: [
      "ABAJO", "ABRIR", "ACTOR", "AGUAS", "AHORA", "AIRES", "ALMAS", "ALTAR", "ALTO", "AMIGO",
      "AMOR", "ANCHO", "ANGEL", "ANTES", "ARBOL", "ARENA", "ARROZ", "ATRAS", "AUTOR", "AVION",
      "AYUDA", "AZOTE", "BAILE", "BANCO", "BARRA", "BEBER", "BELLO", "BESAR", "BICHO", "BINGO",
      "BLUSA", "BOLSA", "BOMBA", "BOSQUE", "BOTAS", "BREVE", "BRISA", "BRUJA", "BUCEO", "BUENO",
      "BURRO", "CABAL", "CABRA", "CACAO", "CAIDA", "CALLE", "CALMA", "CALOR", "CAMPO", "CANAL"
    ],
    6: [
      "ABUELA", "ACEITE", "ACTIVO", "ACTUAL", "ACUDIR", "AGUDO", "AHORRO", "ALEGRE", "ALERTA", "ALIENTO",
      "ALTURA", "AMABLE", "AMANTE", "AMARGO", "AMIGOS", "AMPLIO", "ANCHOS", "ANILLO", "ANIMAL", "ANOMALO",
      "ANTENA", "ANTIGUO", "APLAUSO", "ARAÑA", "ARBOLES", "ARCHIVO", "ARENAS", "ARGOLLA", "ARMADA", "AROMA",
      "ARRIBA", "ARROJO", "ARROZ", "ASALTO", "ASCENSO", "ASIENTO", "ASTUTO", "ATAQUE", "ATENTO", "ATRASO",
      "AUDAZ", "AURORA", "AVANCE", "AVIONES", "AYUDAR", "AZULES", "BAILES", "BAJAR", "BALCON", "BALLET"
    ],
    7: [
      "ABSOLUTO", "ACABADO", "ACAMPAR", "ACEPTAR", "ACORDAR", "ACTITUD", "ACTIVAR", "ACTUAL", "ACUERDO", "ADELANTE",
      "ADENTRO", "ADMIRAR", "ADMITIR", "ADOPTAR", "ADQUIRIR", "ADULTOS", "AFECTAR", "AFILADO", "AFINADO", "AFIRMAR",
      "AGENCIA", "AGITADO", "AGREGAR", "AGUANTAR", "AHOGADO", "AISLADO", "AJUSTAR", "ALCALDE", "ALCANCE", "ALEGRAR",
      "ALENTAR", "ALERGIA", "ALGUIEN", "ALIANZA", "ALIENTO", "ALIGERAR", "ALIMENTO", "ALINEAR", "ALMACEN", "ALMUERZO",
      "ALQUILER", "ALTAVOZ", "ALTERNAR", "ALUMINIO", "ALUMBRAR", "ALZARSE", "AMABLES", "AMBIENTE", "AMENAZA", "AMISTAD"
    ]
  },
  fr: {
    4: [
      "VOIR", "JOUR", "BLEU", "CHAT", "DAME", "FEUX", "LIRE", "MAIN", "NOIR", "PAYS",
      "PEUR", "PLUS", "QUEL", "SAND", "VERS", "YEUX", "ZONE"
    ],
    5: [
      "AMOUR", "BLANC", "COEUR", "DANSE", "ETOIL", "FEMME", "GRAND", "HOMME", "IMAGE",
      "JEUNE", "LIVRE", "MONDE", "NOIRE", "PARIS", "ROUGE", "TERRE", "VILLE"
    ],
    6: [
      "ARGENT", "BUREAU", "CANYON", "DESERT", "ESPRIT", "FLEUVE", "GARAGE", "JARDIN",
      "MAISON", "NATURE", "PLANTE", "SOLEIL", "VOYAGE"
    ]
  },
  de: {
    4: [
      "BUCH", "HAUS", "KIND", "LIED", "MOND", "NAME", "OBST", "RING", "STADT", "TIER",
      "UFER", "VOLK", "WALD", "ZEIT"
    ],
    5: [
      "APFEL", "BAUER", "ESSEN", "FEUER", "GABEL", "HUNDE", "KATZE", "LIEBE", "MUSIK",
      "NATUR", "SONNE", "TISCH", "WOCHE"
    ],
    6: [
      "ARBEIT", "BLUMEN", "GARTEN", "HIMMEL", "KINDER", "LEHRER", "MORGEN", "SCHULE",
      "WASSER", "WOLKEN"
    ]
  }
};

// Helper function to get all words for a given language and length
export function getWordList(language: string, length: number): string[] {
  return dictionaries[language as keyof typeof dictionaries]?.[length as keyof typeof dictionaries['en']] || [];
}

// Helper function to check if a word exists in the dictionary
export function isValidWord(word: string, language: string, length: number): boolean {
  const wordList = getWordList(language, length);
  return wordList.includes(word.toUpperCase());
}

// Helper function to get letter hints
export function getLetterHints(word: string): Set<string> {
  const letterCount = new Map<string, number>();
  for (const letter of word) {
    letterCount.set(letter, (letterCount.get(letter) || 0) + 1);
  }
  return new Set(
    Array.from(letterCount.entries())
      .filter(([_, count]) => count > 1)
      .map(([letter]) => letter)
  );
}