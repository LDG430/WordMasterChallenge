import { Button } from "@/components/ui/button";
import type { Language, TileState } from "@shared/schema";

const KEYBOARD_LAYOUTS = {
  en: [
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
    ["ENTER", "Z", "X", "C", "V", "B", "N", "M", "←"]
  ],
  es: [
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L", "Ñ"],
    ["ENTER", "Z", "X", "C", "V", "B", "N", "M", "←"]
  ],
  fr: [
    ["A", "Z", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["Q", "S", "D", "F", "G", "H", "J", "K", "L", "M"],
    ["ENTER", "W", "X", "C", "V", "B", "N", "É", "←"]
  ],
  de: [
    ["Q", "W", "E", "R", "T", "Z", "U", "I", "O", "P", "Ü"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L", "Ö", "Ä"],
    ["ENTER", "Y", "X", "C", "V", "B", "N", "M", "←"]
  ]
};

interface KeyboardProps {
  language: Language;
  onKey: (key: string) => void;
  onEnter: () => void;
  onBackspace: () => void;
  swapButtons?: boolean;
  hintLetters?: Set<string>;
  letterStates?: Map<string, TileState>;
}

const stateStyles: Record<TileState, string> = {
  empty: "",
  filled: "",
  correct: "bg-green-500 hover:bg-green-600 text-white border-green-500",
  present: "bg-yellow-500 hover:bg-yellow-600 text-white border-yellow-500",
  absent: "bg-gray-500 hover:bg-gray-600 text-white border-gray-500"
};

export function Keyboard({ 
  language, 
  onKey, 
  onEnter, 
  onBackspace, 
  swapButtons,
  hintLetters,
  letterStates = new Map()
}: KeyboardProps) {
  const handleClick = (key: string) => {
    if (key === "ENTER") onEnter();
    else if (key === "←") onBackspace();
    else onKey(key);
  };

  const layout = [...KEYBOARD_LAYOUTS[language]];
  if (swapButtons) {
    const lastRow = layout[2];
    const enterIndex = lastRow.indexOf("ENTER");
    const backspaceIndex = lastRow.indexOf("←");
    [lastRow[enterIndex], lastRow[backspaceIndex]] = [lastRow[backspaceIndex], lastRow[enterIndex]];
  }

  return (
    <div className="grid gap-2">
      {layout.map((row, i) => (
        <div key={i} className="flex justify-center gap-1">
          {row.map((key) => {
            const state = letterStates.get(key);
            return (
              <Button
                key={key}
                variant="outline"
                className={`
                  ${key.length > 1 ? "px-4" : "px-2"}
                  ${state ? stateStyles[state] : ""}
                  ${!state && hintLetters?.has(key) ? "bg-yellow-200 dark:bg-yellow-800" : ""}
                  relative
                `}
                onClick={() => handleClick(key)}
              >
                {key}
                {!state && hintLetters?.has(key) && (
                  <span className="absolute -top-2 -right-1 text-xs">•</span>
                )}
              </Button>
            );
          })}
        </div>
      ))}
    </div>
  );
}