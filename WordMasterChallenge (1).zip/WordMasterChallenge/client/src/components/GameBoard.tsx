
import React from 'react';

function GameBoard({ wordLength = 5, guesses = [], currentGuess = '' }) {
  const emptyRows = Array(6 - guesses.length - 1).fill('');
  
  return (
    <div className="flex flex-col gap-1 p-2 max-w-sm mx-auto">
      {guesses.map((guess, i) => (
        <div key={i} className="grid gap-1" style={{ gridTemplateColumns: `repeat(${wordLength}, 1fr)` }}>
          {guess.map((tile, j) => (
            <div
              key={j}
              className={`
                flex items-center justify-center w-14 h-14 border-2 font-bold text-2xl
                ${tile.state === 'correct' ? 'bg-green-500 border-green-500 text-white' : 
                  tile.state === 'present' ? 'bg-yellow-500 border-yellow-500 text-white' : 
                  tile.state === 'absent' ? 'bg-gray-500 border-gray-500 text-white' : 
                  'border-gray-300'
                }
              `}
            >
              {tile.letter}
            </div>
          ))}
        </div>
      ))}
      
      {/* Current guess row */}
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${wordLength}, 1fr)` }}>
        {Array(wordLength).fill('').map((_, i) => (
          <div
            key={i}
            className="flex items-center justify-center w-14 h-14 border-2 border-gray-300 font-bold text-2xl"
          >
            {currentGuess[i] || ''}
          </div>
        ))}
      </div>

      {/* Empty rows */}
      {emptyRows.map((_, i) => (
        <div key={i} className="grid gap-1" style={{ gridTemplateColumns: `repeat(${wordLength}, 1fr)` }}>
          {Array(wordLength).fill('').map((_, j) => (
            <div
              key={j}
              className="flex items-center justify-center w-14 h-14 border-2 border-gray-300 font-bold text-2xl"
            />
          ))}
        </div>
      ))}
    </div>
  );
}

export default GameBoard;
