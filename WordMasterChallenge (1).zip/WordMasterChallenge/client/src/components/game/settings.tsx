import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/hooks/use-theme";

interface GameSettings {
  hardMode: boolean;
  dailyMode: boolean;
  colorBlindMode: boolean;
  letterHints: boolean;
  confettiAnimation: boolean;
  swapButtons: boolean;
}

interface SettingsProps {
  open: boolean;
  onClose: () => void;
  settings: GameSettings;
  onSettingChange: (setting: keyof GameSettings) => void;
}

export function SettingsPanel({ open, onClose, settings, onSettingChange }: SettingsProps) {
  const { toast } = useToast();
  const { setTheme, theme } = useTheme();

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Game Settings</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="hard-mode">Hard Mode</Label>
              <p className="text-sm text-muted-foreground">
                Use revealed hints in subsequent guesses
              </p>
            </div>
            <Switch 
              id="hard-mode"
              checked={settings.hardMode}
              onCheckedChange={() => onSettingChange("hardMode")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="daily-mode">Daily Mode</Label>
              <p className="text-sm text-muted-foreground">
                New word chain every 24 hours
              </p>
            </div>
            <Switch 
              id="daily-mode"
              checked={settings.dailyMode}
              onCheckedChange={() => {
                onSettingChange("dailyMode");
                toast({
                  title: "Daily Mode",
                  description: settings.dailyMode 
                    ? "Switched to free play mode" 
                    : "You'll get new word chains every 24 hours",
                });
              }}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="theme">Dark Mode</Label>
              <p className="text-sm text-muted-foreground">
                Switch between light and dark theme
              </p>
            </div>
            <Switch 
              id="theme"
              checked={theme === "dark"}
              onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="color-blind">Color Blind Mode</Label>
              <p className="text-sm text-muted-foreground">
                High contrast colors for better visibility
              </p>
            </div>
            <Switch 
              id="color-blind"
              checked={settings.colorBlindMode}
              onCheckedChange={() => onSettingChange("colorBlindMode")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="letter-hints">Letter Hints</Label>
              <p className="text-sm text-muted-foreground">
                Show when letters appear multiple times
              </p>
            </div>
            <Switch 
              id="letter-hints"
              checked={settings.letterHints}
              onCheckedChange={() => onSettingChange("letterHints")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="confetti">Confetti Animation</Label>
              <p className="text-sm text-muted-foreground">
                Celebrate wins with confetti
              </p>
            </div>
            <Switch 
              id="confetti"
              checked={settings.confettiAnimation}
              onCheckedChange={() => onSettingChange("confettiAnimation")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="swap-buttons">Swap Enter/Backspace</Label>
              <p className="text-sm text-muted-foreground">
                Switch keyboard button positions
              </p>
            </div>
            <Switch 
              id="swap-buttons"
              checked={settings.swapButtons}
              onCheckedChange={() => onSettingChange("swapButtons")}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function SettingsButton({ onClick }: { onClick: () => void }) {
  return (
    <Button variant="ghost" size="icon" onClick={onClick}>
      <Settings2 className="h-5 w-5" />
    </Button>
  );
}
