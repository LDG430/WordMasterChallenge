
import { generateId } from './utils';
import type { GameStats, Language, PlayerState } from '@shared/schema';

class Storage {
  private wordCache: Record<Language, Record<number, string[]>> = {
    en: {}, es: {}, fr: {}, de: {}
  };
  private rooms = new Map<string, any>();
  private stats: GameStats = {
    gamesPlayed: 0,
    gamesWon: 0,
    currentStreak: 0,
    maxStreak: 0,
    distribution: [0, 0, 0, 0, 0, 0]
  };

  // Language-specific word lists
  private wordLists: Record<Language, Record<number, string[]>> = {
    en: {
      4: ["ABLE", "ACID", "AGED", "ALSO", "AREA", "AWAY", "BABY", "BACK", "BALL", "BANK", "BLUE", "BOOK", "CALM", "CARD", "CITY"],
      5: ["ABOUT", "ABOVE", "ABUSE", "ACTOR", "ACUTE", "ADMIT", "ADOPT", "ADULT", "AFTER", "AGAIN", "ALERT", "APPLE", "BEACH", "BLACK"],
      6: ["ABROAD", "ACCEPT", "ACCESS", "ACROSS", "ACTING", "ACTION", "ACTIVE", "ADVICE", "AFFORD", "AGENCY", "APPEAR", "BATTLE"]
    },
    es: {
      4: ["AMOR", "CASA", "GATO", "LUNA", "MESA", "NIÑO", "PATO", "ROJO", "VIDA", "VINO"],
      5: ["AMIGO", "CAMPO", "FELIZ", "GATOS", "LIBRO", "PLAYA", "VERDE", "DULCE"],
      6: ["AMIGOS", "COCINA", "JARDIN", "ESCUELA", "TIEMPO", "TRABAJO", "COMIDA"]
    },
    fr: {
      4: ["CHAT", "PAIN", "VERT", "NOIR", "BLEU", "PEUR", "PLUS", "JOUR", "LIRE"],
      5: ["CHIEN", "ROUGE", "BLANC", "TABLE", "LIVRE", "POMME", "MONDE", "FEMME"],
      6: ["MAISON", "JARDIN", "SOLEIL", "ENFANT", "LETTRE", "MUSIQUE", "ETOILE"]
    },
    de: {
      4: ["HAUS", "HUND", "BUCH", "WEIN", "BALL", "ZEIT", "BROT", "GELD", "HERZ"],
      5: ["KATZE", "MAUER", "TISCH", "STUHL", "GRUEN", "BLUME", "MUSIK"],
      6: ["GARTEN", "WASSER", "SOMMER", "WINTER", "ARBEIT", "FREUND", "BERLIN"]
    }
  };

  private validateLanguageWord(word: string, language: Language): boolean {
    const patterns: Record<Language, RegExp> = {
      en: /^[A-Z]+$/,
      es: /^[A-ZÁÉÍÓÚÑ]+$/,
      fr: /^[A-ZÀÂÄÉÈÊËÎÏÔÖÙÛÜŸÇ]+$/,
      de: /^[A-ZÄÖÜß]+$/
    };
    return patterns[language].test(word);
  }

  private async fetchWords(language: Language, length: number): Promise<string[]> {
    if (this.wordCache[language][length]) {
      return this.wordCache[language][length];
    }

    const words = this.wordLists[language][length] || [];
    const validWords = words.filter(word => 
      word.length === length && 
      this.validateLanguageWord(word, language)
    );

    this.wordCache[language][length] = validWords;
    return validWords;
  }

  async getRandomWord(length: number, language: Language): Promise<string> {
    const words = await this.fetchWords(language, length);
    if (words.length === 0) {
      return this.wordLists[language][length][0];
    }
    return words[Math.floor(Math.random() * words.length)];
  }

  async validateWord(word: string, language: Language = 'en'): Promise<boolean> {
    const words = await this.fetchWords(language, word.length);
    return words.includes(word.toUpperCase());
  }

  async createRoom(language: Language, wordLength: number): Promise<string> {
    const roomId = generateId();
    const word = await this.getRandomWord(wordLength, language);
    this.rooms.set(roomId, {
      id: roomId,
      language,
      wordLength,
      word,
      players: {},
      createdAt: Date.now()
    });
    return roomId;
  }

  async getRoomState(roomId: string) {
    return this.rooms.get(roomId);
  }

  async joinRoom(roomId: string, playerId: string, playerName: string) {
    const room = this.rooms.get(roomId);
    if (!room) return null;
    
    room.players[playerId] = {
      id: playerId,
      name: playerName,
      guesses: [],
      currentRow: 0,
      gameState: 'playing'
    };
    
    return room;
  }

  async leaveRoom(roomId: string, playerId: string) {
    const room = this.rooms.get(roomId);
    if (!room) return;
    
    delete room.players[playerId];
    if (Object.keys(room.players).length === 0) {
      this.rooms.delete(roomId);
    }
  }

  async updatePlayerState(roomId: string, playerId: string, state: Partial<PlayerState>) {
    const room = this.rooms.get(roomId);
    if (!room || !room.players[playerId]) return null;
    
    room.players[playerId] = {
      ...room.players[playerId],
      ...state
    };
    
    return room;
  }

  async getGameStats(): Promise<GameStats> {
    return this.stats;
  }

  async updateGameStats(won: boolean, attempts: number): Promise<GameStats> {
    this.stats.gamesPlayed++;
    if (won) {
      this.stats.gamesWon++;
      this.stats.currentStreak++;
      this.stats.maxStreak = Math.max(this.stats.maxStreak, this.stats.currentStreak);
      if (attempts >= 1 && attempts <= 6) {
        this.stats.distribution[attempts - 1]++;
      }
    } else {
      this.stats.currentStreak = 0;
    }
    return this.stats;
  }
}

export const storage = new Storage();
