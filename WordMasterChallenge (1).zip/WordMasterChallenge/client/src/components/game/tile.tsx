import { motion } from "framer-motion";
import type { TileState } from "@shared/schema";

interface TileProps {
  letter: string;
  state: TileState;
  revealed: boolean;
  colorBlindMode?: boolean;
}

const regularStateStyles: Record<TileState, string> = {
  empty: "border-2 border-gray-300 dark:border-gray-600",
  filled: "border-2 border-gray-600 dark:border-gray-300",
  correct: "bg-green-500 text-white border-green-500",
  present: "bg-yellow-500 text-white border-yellow-500",
  absent: "bg-gray-500 text-white border-gray-500"
};

const colorBlindStateStyles: Record<TileState, string> = {
  empty: "border-2 border-gray-300 dark:border-gray-600",
  filled: "border-2 border-gray-600 dark:border-gray-300",
  correct: "bg-blue-600 text-white border-blue-600",
  present: "bg-orange-500 text-white border-orange-500",
  absent: "bg-gray-500 text-white border-gray-500"
};

export function Tile({ letter, state, revealed, colorBlindMode }: TileProps) {
  const stateStyles = colorBlindMode ? colorBlindStateStyles : regularStateStyles;

  return (
    <motion.div
      className={`w-14 h-14 flex items-center justify-center text-2xl font-bold rounded ${stateStyles[state]}`}
      initial={false}
      animate={{
        rotateX: revealed ? 360 : 0,
        scale: letter ? 1.1 : 1,
      }}
      transition={{
        type: "spring",
        stiffness: 200,
        damping: 20
      }}
    >
      {letter}
    </motion.div>
  );
}