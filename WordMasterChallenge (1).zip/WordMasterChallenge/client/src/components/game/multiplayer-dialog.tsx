
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface MultiplayerDialogProps {
  open: boolean;
  onClose: () => void;
  onCreateRoom: () => void;
  onJoinRoom: (roomId: string) => void;
  playerName: string;
  setPlayerName: (name: string) => void;
}

export function MultiplayerDialog({
  open,
  onClose,
  onCreateRoom,
  onJoinRoom,
  playerName,
  setPlayerName,
}: MultiplayerDialogProps) {
  const [roomId, setRoomId] = useState("");

  const handleCreateRoom = () => {
    if (!playerName.trim()) {
      alert("Please enter your name");
      return;
    }
    onCreateRoom();
  };

  const handleJoinRoom = () => {
    if (!playerName.trim()) {
      alert("Please enter your name");
      return;
    }
    if (!roomId.trim()) {
      alert("Please enter a room code");
      return;
    }
    onJoinRoom(roomId.toUpperCase());
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-md bg-background">
        <DialogHeader>
          <DialogTitle className="text-foreground">Multiplayer Room</DialogTitle>
          <div className="text-sm text-muted-foreground">
            Create or join a multiplayer room to play with friends
          </div>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Your Name</Label>
            <Input
              id="name"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              placeholder="Enter your name"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Button 
                variant="default" 
                className="w-full" 
                onClick={handleCreateRoom}
              >
                Create Room
              </Button>
            </div>
            <div className="space-y-2">
              <div className="flex gap-2">
                <Input
                  value={roomId}
                  onChange={(e) => setRoomId(e.target.value.toUpperCase())}
                  placeholder="Room Code"
                  maxLength={6}
                />
                <Button 
                  variant="secondary" 
                  onClick={handleJoinRoom}
                >
                  Join
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
